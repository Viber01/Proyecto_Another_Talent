create table Usuarios(
id_Usuario SMALLSERIAL NOT NULL PRIMARY KEY,
imaPerfil varchar,
portada varchar,
nombre varchar not null,
apellidos varchar not null,
correo varchar not null,
contraseña varchar not null
);

select*from Usuarios;
delete from Usuarios;

select portada from Usuarios where correo = 'a16pxndx@hotmail.com';  

create table video(
id_Video SMALLSERIAL NOT NULL PRIMARY KEY,
id_Usuario SMALLINT not null,
nombreV varchar not null,
tituloV varchar not null
);

select*from video;
delete from video;


select 






