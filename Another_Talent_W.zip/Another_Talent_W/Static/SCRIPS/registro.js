$(document).ready(alertaCorreo);

document.getElementById("ocupado").style.display = "none";

document.getElementById('banderaN').style.display = "none";
document.getElementById('banderaA').style.display = "none";
document.getElementById('banderaC').style.display = "none";

function alertaCorreo(){
    var bandera = document.getElementById('ocupado');
    var alert = document.getElementById('usa');
   
    var nombre = document.getElementById('banderaN');
    var apellido = document.getElementById('banderaA');
    var correo = document.getElementById('banderaC');

    var insertNombre = document.getElementById('name');
    var insertApellido = document.getElementById('lastname');
    var insertCorreo = document.getElementById('email');

    if (bandera.innerHTML == "ocupado") {
        alert.style.fontFamily = " Arial, Helvetica, sans-serif";
        alert.style.fontSize = "14px";
        alert.style.color = "red";
        alert.innerHTML = "El correo ya a sido utilizado* (inserte un nuevo correo)";   


        insertNombre.value = nombre.innerHTML;
        insertApellido.value = apellido.innerHTML;
        insertCorreo.value = correo.innerHTML;
    }
}

