$(document).ready(fondo);
$(document).ready(resubir);
$(document).ready(cancelar);
$(document).ready(enviar);
$(document).ready(resubir1);
$(document).ready(cancelar1);
$(document).ready(enviar1);
$(document).ready(resubirvideo);
$(document).ready(cancelarvideo);
$(document).ready(enviarvideo);
$(document).ready( newPerfil);


$(document).ready(emergenteV);

function emergenteV(){

        $('.video').click(function () {
                $('.viE').click();

        });  

}

function re() {

        document.getElementById('subirvideo').style.display = "block";
        
}


function newPerfil() {
        $('.cambiar').click(function () {
                $('.archivador2').click();

        });
}

function fondo() {
        $('.subir').click(function () {
                $('.archivador').click();

        });
}

function enviar() {
        $('.subir3').click(function () {
                $('.enviar').click();
        });
}

function cancelar() {
        $('.subir4').click(function () {
                document.getElementById('contenedor').style.display = "none";
        });
}

function resubir() {
        $('.subir2').click(function () {
                $('.archivador').click();
        });
}


function enviar1() {
        $('.subir6').click(function () {
                $('.enviar2').click();
        });
}

function cancelar1() {
        $('.subir7').click(function () {
                document.getElementById('visorPerfil').style.display = "none";
        });
}

function resubir1() {
        $('.subir5').click(function () {
                $('.archivador2').click();
        });
}




function enviarvideo() {
        $('.subirV').click(function () {
                $('.enviarVIDEO').click();
        });
}

function cancelarvideo() {
        $('.cancelarV').click(function () {
                document.getElementById('subirvideo').style.display = "none";
        });
}

function resubirvideo() {
        $('.cambiarV').click(function () {
                $('.viE').click();
        });
}





function correr() {
        var imgV = document.getElementById('emergente');
        var imageUploader = document.getElementById('archivador');
        var Ruta = imageUploader.value;
        var extPermitidos = /(.png|.jpg)$/i;

        if (!extPermitidos.exec(Ruta)) {
                alert('Selecciona una imagen');
                imageUploader = 0;
                return false;
        }
        else {
                if (imageUploader.files && imageUploader.files[0]) {
                        var visor = new FileReader();
                        visor.onload = function (e) {
                                imgV.style.background = "url(" + e.target.result + ") no-repeat top center";
                                imgV.style.backgroundSize = "cover";
                                imgV.style.hover = 'black';
                                document.getElementById('contenedor').style.display = "block";
                        };
                        visor.readAsDataURL(imageUploader.files[0]);
                }
        }
}

function correr1() {
        var imgV = document.getElementById('pre');
        var imageUploader = document.getElementById('archivador2');
        var Ruta = imageUploader.value;
        var extPermitidos = /(.png|.jpg)$/i;

        if (!extPermitidos.exec(Ruta)) {
                alert('Selecciona una imagen');
                imageUploader = 0;
                return false;
        }
        else {
                if (imageUploader.files && imageUploader.files[0]) {
                        var visor = new FileReader();
                        visor.onload = function (e) {
                                imgV.style.background = "url(" + e.target.result + ") no-repeat top center";
                                imgV.style.backgroundSize = "cover";
                                imgV.style.hover = 'black';
                                document.getElementById('visorPerfil').style.display = "block";
                        };
                        visor.readAsDataURL(imageUploader.files[0]);
                }
        }
}








var portada = document.getElementById('portada');
var plasmar = document.getElementById('muro');
var rut = portada.innerHTML;

if (rut == "") {

        plasmar.style.background = "black no-repeat top center";
        plasmar.style.backgroundSize = "cover";
        plasmar.style.hover = 'black';


} else if (rut != null) {
        plasmar.style.background = "url(../UPLOADS/" + rut + ") no-repeat top center";
        plasmar.style.backgroundSize = "cover";
        plasmar.style.hover = 'black';
}

var Ruta = document.getElementById('perfil');
var icon = document.getElementById('avatar');
var rut = Ruta.innerHTML;
console.log(rut);

if (rut == "") {

        icon.style.background = "black no-repeat top center";
        icon.style.backgroundSize = "cover";
        icon.style.hover = 'black';


} else if (rut != null) {
        icon.style.background = "url(../" + rut + ") no-repeat top center";
        icon.style.backgroundSize = "cover";
        icon.style.hover = 'black';
}


