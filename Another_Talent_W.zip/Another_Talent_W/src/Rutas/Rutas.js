const multer = require('multer');
const { Router } = require('express');
const router = Router();
const { v4 : uuidv4 } = require('uuid');
const conector = require('../Conector/Conector');
const conect = conector();
const path = require('path');
const { request } = require('http');
const { connect } = require('http2');
const { route } = require('../Configuracion/Config');
conect.connect()

var temporal = "";

var bandera = "disponible";
var banderaNombre = "";
var banderaApellido = "";
var banderaCorreo = "";

const storage = multer.diskStorage({
   destination: path.join(__dirname, '../../Static/UPLOADS'),
   filename: (req, file, cb) => {
      cb(null, uuidv4() + path.extname(file.originalname).toLocaleLowerCase());

   }
});

const use = multer({
   storage: storage,
   dest: path.join(__dirname, '../../Static/UPLOADS'),
   fileFilter: (req, file, cb) => {
      const filetypes = /|jpeg|jpg|png|docx|pdf|PDF/
      const mimetype = filetypes.test(file.mimetype);
      const extname = filetypes.test(path.extname(file.originalname));

      if (mimetype && extname) {
         return cb(null, true);
      }
      cb("Error: Archivo debe ser una imagen valida")
   }
}).single('image');


router.get('/', (req, res) => {
conect.query("select U.nombre, U.apellidos, U.imaPerfil, V.nombreV, V.tituloV from video V inner join Usuarios U on U.id_Usuario = V.id_Usuario;", (err, result) => {
   var datos = result.rows;  
   bandera = "disponible";
   res.render('index', {
      datos
   })
});
  
});

router.get('/anotherTalent/login', (req, res) => {
   bandera = "disponible";
   res.render('login');

});

router.get('/anotherTalent/registro', (req, res) => {

   res.render('registro',{
      bandera,
      banderaNombre,
      banderaApellido,
      banderaCorreo
   });

});

router.get('/anotherTalent/registro/terminal', (req, res) => {

   conect.query("select nombre, apellidos from Usuarios  where correo = '" + temporal + "';", (err, result) => {
     
      var nombre = result.rows[0].nombre + " " + result.rows[0].apellidos;
     
      res.render('registroP', {
         nombre
      });  
   
   });
    
});


router.get('/anotherTalent/perfil', (req, res) => {
   conect.query("select nombre, apellidos, portada, imaperfil, id_usuario from Usuarios  where correo = '" + temporal + "';", (err, result) => {
      var name = result.rows[0].nombre + " " + result.rows[0].apellidos;
      var portada = result.rows[0].portada;
      var perfil = result.rows[0].imaperfil

   conect.query("select nombrev, titulov from video where id_usuario = '" + result.rows[0].id_usuario + "';", (err, result) => {
      var datosVideos = result.rows; 
  
      res.render('perfil', {
         portada,
         perfil,
         name,
         datosVideos
      });  

      });


   });
});



//Metodos POST trafico de datos 

router.post('/registro', (req, res) => {

   console.log(req.body);
   const { nombre, apellidos, email, contraseña } = req.body;
   var comprovar = false;
   temporal = email;
   conect.query("select*from Usuarios;", (err, result) => {
      console.log(result.rows);
      for (var i = 0; i < result.rowCount; i++) {
      
         if (result.rows[i].correo == email) { 
            comprovar = true;
            break;
         }
      }

      if (comprovar == true) {

         bandera = "ocupado";
         banderaNombre = nombre;
         banderaApellido = apellidos;
         banderaCorreo = email;
         res.redirect("/anotherTalent/registro");
        

      } else {
         try {
            conect.query("insert into Usuarios(nombre, apellidos, correo, contraseña) values ($1,$2,$3,$4);", [nombre, apellidos, email, contraseña], (err, result) => {
               res.redirect('/anotherTalent/registro/terminal');
            });
         } catch (e) {
            console.log('error al subir los datos');
         }
      }
   });




});

//Cargar foto de perfil

router.post('/Personalizar', use, (req, res) => {
   var foto = "UPLOADS/" + req.file.filename;

conect.query("UPDATE Usuarios set imaperfil =  '" + foto + "' where correo = '" + temporal + "';", (err, result) =>{
  res.redirect("/anotherTalent/perfil");
});

});



//INICIAR SESION

router.post("/iniciar_sesion", (req, res) => {
   const { contraseña, correo } = req.body;
   temporal = correo;
   conect.query('select correo, contraseña from Usuarios', (err, result) => {
      for (let index = 0; index < result.rowCount; index++) {
         if (correo == result.rows[index].correo && contraseña == result.rows[index].contraseña) {
            res.redirect('/anotherTalent/perfil');         
            ucer = true;
            iniciar = correo;
      }
      }

   });

});

//cargar foto de portada

router.post("/portada", use, (req, res) =>{
   
   conect.query("UPDATE Usuarios set portada =  '" + req.file.filename + "' where correo = '" + temporal + "';", (err, result) =>{
      res.redirect("/anotherTalent/perfil");
    });

});


//cargar nueva foto de perfil


router.post('/subirp', use, (req, res) =>{
   var foto = "UPLOADS/" + req.file.filename;
   conect.query("UPDATE Usuarios set imaperfil =  '" + foto + "' where correo = '" + temporal + "';", (err, result) =>{
      res.redirect("/anotherTalent/perfil");
    });

});

//cargar video

router.post('/subirvideo', use, (req, res) => {
   const { titulo } = req.body;
   var videoname = "UPLOADS/" + req.file.filename;
   conect.query("select id_Usuario from Usuarios  where correo = '" + temporal + "';", (err, result) => {
   var idE = result.rows[0].id_usuario;

      conect.query("insert into video(id_Usuario, nombreV, tituloV) values ($1,$2,$3);", [idE, videoname, titulo]);

      res.redirect("/anotherTalent/perfil");

   });

});




module.exports = router;










