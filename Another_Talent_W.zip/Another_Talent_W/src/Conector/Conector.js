const  {Client}  = require('pg')

const client = new Client({
    user: "postgres",
    password: "yahaira",
    host: "localhost",
    port: 5432,
    database: "Another_Talent"
})

module.exports =  () => {
    return client;
}