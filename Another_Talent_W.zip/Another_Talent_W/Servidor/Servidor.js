const app = require('../src/Configuracion/Config');
app.use(require('../src/Rutas/Rutas'));

app.listen(app.get('port'), () => {
   console.log('Servidor en el puerto ', app.get('port'));    
}); 